#pragma once

#include "httplib.h"
#include <nlohmann/json.hpp>
#include <string>
#include <regex>

namespace solver {
using namespace std;

enum class Mode {
    Development,
    Standalone,
    Node
};


const string official_server_ip = "112.137.129.202";
const int official_server_port = 8000;
const string token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NCwibmFtZSI6IkNUVS5CRlMiLCJpc19hZG1pbiI6ZmFsc2UsImlhdCI6MTc2MDQyODEyNSwiZXhwIjoxNzYwNjAwOTI1fQ.DCMBBjqWzh-apNxLlBSpumxZxwK3Netf3dskIVfYmoI";


enum class IOType {
    Standard,
    File,
    OfficialServer,
    InnerServer
};


enum class DataType {
    Json,
    Raw
};

class Solver {
  public:
    Solver(Mode mode, IOType iotype, DataType dataType, int argc, char *argv[]) : mode_(mode), ioType_(iotype), dataType_(dataType), task_id_(0), required_exit_(false) {
        if (mode_ == Mode::Standalone) {
            ioType_ = IOType::OfficialServer;
            dataType_ = DataType::Json;
        }

        if (mode_ == Mode::Node) {
            ioType_ = IOType::InnerServer;
            dataType_ = DataType::Json;
        }

        if (ioType_ == IOType::File) {
            if (argc < 3) {
                throw runtime_error("Arguments required input / output file path.");
            }

            inputFile_ = argv[1];
            // inputFile_ = "/home/khmt/Documents/TQKhangT/procon2025/input.json";
            outputFile_ = argv[2];
            // outputFile_ = "/Users/quockhang/CLionProjects/cp/output.json";
        }


        if (ioType_ == IOType::OfficialServer) {
            server_ip_ = official_server_ip;
            server_port_ = official_server_port;
            dataType_ = DataType::Json;
        }

        if (ioType_ == IOType::InnerServer) {
            if (argc < 4) {
                throw runtime_error("Missing inner server IP, Port, TaskId.");
            }

            server_ip_ = argv[1];
            server_port_ = stoi(argv[2]);
            task_id_ = stoi(argv[3]);
            dataType_ = DataType::Json;

            if (argc > 4) {
                if (string(argv[4]) == "CONNECTION_TEST") {
                    httplib::Client cli(server_ip_, server_port_);
                    if (auto res = cli.Get("/check/" + to_string(task_id_))) {
                        if (res->status == 200) {
                            cout << "Success: " << task_id_ << " received status 200." << endl;
                        } else {
                            cerr << "Error: Return status invalid. Status: " << res->status << endl;
                        }
                    } else {
                        auto err = res.error();
                        cerr << "Error: Failed to connect to server. " << httplib::to_string(err) << endl;
                    }
                    required_exit_ = true;
                }
            }
        }
    }

    nlohmann::json getProblem() {
        nlohmann::json problem;
        switch (ioType_) {
        case IOType::File:
            // TODO
            cerr << "Input file: " << inputFile_ << endl;
            if (dataType_ == DataType::Json) {
                ifstream i(inputFile_);
                nlohmann::json j;
                i >> j;
                return j;
            }
            break;

        case IOType::Standard:
            cerr << "Reading from stdin..." << endl;
            if (dataType_ == DataType::Raw) {
                size_t grid_size;
                cin >> grid_size;
                problem["problem"]["field"]["size"] = grid_size;
                vector<int> input_v(grid_size, 0);
                for (size_t i = 0; i < grid_size; ++i) {
                    for (size_t j = 0; j < grid_size; ++j) {
                        cin >> input_v[j];
                    }
                    problem["problem"]["field"]["entities"].push_back(input_v);
                }
                cerr << "Finished reading stdin." << endl;
            } else {
                string line, input_json_str;
                while (getline(cin, line)) {
                    input_json_str += line;
                }
                cerr << "Finished reading stdin." << endl;
                if (!input_json_str.empty()) {
                    try {
                        problem = nlohmann::json::parse(input_json_str);
                    } catch (const nlohmann::json::parse_error &e) {
                        cerr << "JSON parse error: " << e.what() << endl;
                    }
                }
            }
            break;

        case IOType::OfficialServer: {
            httplib::Client cli(server_ip_, server_port_);
            task_id_ = 1;
            cout << "Task ID: " << task_id_ << endl;
            while (true) {
                if (auto res = cli.Get("/question/" + to_string(task_id_), {{"authorization", token}})) {
                    if (res->status == 200) {
                        cout << "200 --->" << endl;
                        cout << res->body << endl;
                        cout << "200 --->" << endl;
                        std::string body = res->body;
                        cout << body << endl;
                        cout << "200 --->" << endl;
                        // problem = nlohmann::json::parse(res->body);
                        try {
                            // problem = nlohmann::json::parse(body).get<std::string>();
                            // xử lý JSON ở đây
                            problem = nlohmann::json::parse(body);
                            cout << body << endl;
                            break;
                        } catch (const std::exception &e) {
                            cerr << "JSON parse error: " << e.what() << endl;
                        }
                        break;
                    } else {
                        cerr << "Error: Failed to get problem. Status: " << res->status << endl;
                    }
                } else {
                    auto err = res.error();
                    cerr << "\rError: Failed to connect to server. " << httplib::to_string(err) << flush;
                }
            }
            cout << endl;
        } break;

        case IOType::InnerServer: {
            httplib::Client cli(server_ip_, server_port_);
            while (true) {
                if (auto res = cli.Get("/problem/" + to_string(task_id_))) {
                    if (res->status == 200) {
                        problem = nlohmann::json::parse(res->body);
                        break;
                    } else {
                        cerr << "Error: Failed to get problem. Status: " << res->status << endl;
                    }
                } else {
                    auto err = res.error();
                    cerr << "\rError: Failed to connect to server. " << httplib::to_string(err) << flush;
                }
            }
            cout << endl;
        } break;

        default:
            cerr << "Unknown io type." << endl;
            exit(1);
            break;
        }

        return problem;
    }

    void submitAnswer(const nlohmann::json &answer) {
        switch (ioType_) {
        case IOType::File:
            // TODO
            cerr << "Output file: " << outputFile_ << endl;
            if (dataType_ == DataType::Json) {
                ofstream o(outputFile_);
                o << answer << endl;
            }
            break;

        case IOType::Standard:
            if (ioType_ == IOType::Standard) {
                if (dataType_ == DataType::Json) {
                    cout << answer.dump() << endl;
                } else {
                    size_t grid_size = answer["problem"]["field"]["size"].get<int>();
                    vector<vector<int>> ent;
                    ent = answer["problem"]["field"]["entities"].get<vector<vector<int>>>();
                    cout << grid_size << endl;
                    for (size_t i = 0; i < grid_size; ++i) {
                        for (size_t j = 0; j < grid_size; ++j) {
                            cout << ent[i][j] << ' ';
                        }
                        cout << endl;
                    }
                }
            }
            break;

        case IOType::OfficialServer: {
            httplib::Client cli(server_ip_, server_port_);
            string body = answer.dump();
            // http://112.137.129.202:8000/answer
            if (auto res = cli.Post("/answer", {{"authorization", token}}, body, "application/json")) {
                if (res->status == 200) {
                    cerr << "Success: Submit answer to server. Status: " << res->status << endl;
                    break;
                } else {
                    auto err = res.error();
                    cerr << "Error: Failed to submit to server. " << httplib::to_string(err) << endl;
                }
            } else {
                auto err = res.error();
                cerr << "Error: Failed to connect to server. " << httplib::to_string(err) << endl;
            }
            cerr << body << endl;
        } break;

        case IOType::InnerServer: {
            httplib::Client cli(server_ip_, server_port_);
            string body = answer.dump();
            for (int i = 0; i < 10; ++i) {
                if (auto res = cli.Post("/answer/" + to_string(task_id_), body, "application/json")) {
                    if (res->status == 200) {
                        cerr << "Success: Submit answer to server. Status: " << res->status << endl;
                        break;
                    } else {
                        auto err = res.error();
                        cerr << "Error: Failed to submit to server. " << httplib::to_string(err) << endl;
                    }
                } else {
                    auto err = res.error();
                    cerr << "Error: Failed to connect to server. " << httplib::to_string(err) << endl;
                }
            }
        } break;

        default:
            cerr << "Unknown io type." << endl;
            exit(1);
            break;
        }
    }

    void submitPartial(const nlohmann::json &answer) {
        if (ioType_ != IOType::InnerServer) {
            cerr << "Error: submitPartial is only available in InnerServer mode." << endl;
            return;
        }
        httplib::Client cli(server_ip_, server_port_);
        string body = answer.dump();
        for (int i = 0; i < 10; ++i) {
            if (auto res = cli.Post("/partial", body, "application/json")) {
                if (res->status == 200) {
                    cerr << "Success: Submit answer to server. Status: " << res->status << endl;
                    break;
                } else {
                    auto err = res.error();
                    cerr << "Error: Failed to submit to server. " << httplib::to_string(err) << endl;
                }
            } else {
                auto err = res.error();
                cerr << "Error: Failed to connect to server. " << httplib::to_string(err) << endl;
            }
        }
    }

    bool shouldExit() {
        return required_exit_;
    }

  private:
    Mode mode_;
    IOType ioType_;
    DataType dataType_;
    string inputFile_, outputFile_;
    string server_ip_;
    int server_port_;
    int task_id_;
    bool required_exit_;
};

} // namespace solver