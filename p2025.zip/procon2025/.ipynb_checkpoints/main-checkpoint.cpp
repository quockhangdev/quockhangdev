#include <bits/stdc++.h>

using namespace std;

#include "BS_thread_pool.hpp"
#include <atcoder/segtree.hpp>
#include <fstream>
#include <iostream>
#include <nlohmann/json.hpp>

#include "solver.hpp"

#ifndef BEAM_WIDTH
#define BEAM_WIDTH 30000
#endif // !BEAM_WIDTH

constexpr int max_turn = 80;

using base = uint8_t;

namespace grid_hash {
  struct SplitMix64 {
    static std::uint64_t next(std::uint64_t &x) noexcept {
      x += 0x9e3779b97f4a7c15ULL;
      std::uint64_t z = x;
      z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
      z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
      return z ^ (z >> 31);
    }
  };

  template<typename Getter, typename Grid>
  concept GridGetter =
      std::invocable<Getter, std::uint32_t, std::uint32_t, const Grid &> &&
      std::unsigned_integral<std::invoke_result_t<Getter, std::uint32_t,
        std::uint32_t, const Grid &> >;

  template<typename Grid, GridGetter<Grid> Getter>
  class GridHash {
  public:
    using value_t = std::uint32_t;
    using hash_t = std::uint64_t;

    std::vector<std::pair<value_t, value_t> > pairs_;

    GridHash(
      std::uint32_t n, Getter getter,
      std::uint64_t seed =
          0x9E3779B97F4A7C15ULL) noexcept(std::
      is_nothrow_copy_constructible_v<
        Getter>)
      : n_(n), getter_(getter), hash_(0), quickUndo_(false) {
      p_len_ = n_ * n_ / 2;
      h_len_ = p_len_ * (p_len_ * 2 - 1);
      saved_indexes_.reserve(n_ * n_);
      init_table(seed);
    }

    hash_t build(const Grid &grid) noexcept {
      constexpr std::uint32_t invalid_number = 1024;
      hash_ = 0;
      pairs_.assign(p_len_, std::pair<uint32_t, uint32_t>(
                      {invalid_number, invalid_number}));
      saved_pairs_.assign(p_len_, std::pair<uint32_t, uint32_t>(
                            {invalid_number, invalid_number}));

      for (std::size_t j = 0; j < n_; ++j) {
        for (std::size_t i = 0; i < n_; ++i) {
          std::size_t idx = static_cast<std::size_t>(getter_(i, j, grid));
          if (pairs_[idx].first == invalid_number) {
            pairs_[idx].first = j * n_ + i;
          } else {
            pairs_[idx].second = j * n_ + i;
          }
        }
      }

      for (std::size_t i = 0; i < p_len_; ++i) {
        hash_ ^= table_[index_for(i)];
      }
      return hash_;
    }

    hash_t apply_operation(const Grid &grid, uint32_t x, uint32_t y,
                           uint32_t n) noexcept {
      for (std::size_t j = 0; j < n; ++j) {
        for (std::size_t i = 0; i < n; ++i) {
          std::size_t idx = static_cast<std::size_t>(getter_(x + i, y + j, grid));
          hash_ ^= table_[index_for(idx)];

          uint32_t before = (y + j) * n_ + x + i,
              after = (y + i) * n_ + x + n - 1 - j;
          if (pairs_[idx].first == before)
            pairs_[idx].first = after;
          else
            pairs_[idx].second = after;

          hash_ ^= table_[index_for(idx)];
        }
      }

      quickUndo_ = false;
      return hash_;
    }

    hash_t apply_operation_with_quickundo(const Grid &grid, uint32_t x,
                                          uint32_t y, uint32_t n) noexcept {
      saved_hash_ = hash_;
      saved_indexes_.clear();
      for (std::size_t j = 0; j < n; ++j) {
        for (std::size_t i = 0; i < n; ++i) {
          std::size_t idx = static_cast<std::size_t>(getter_(x + i, y + j, grid));
          hash_ ^= table_[index_for(idx)];

          saved_indexes_.emplace_back(idx);
          saved_pairs_[idx] = pairs_[idx];

          uint32_t before = (y + j) * n_ + x + i,
              after = (y + i) * n_ + x + n - 1 - j;
          if (pairs_[idx].first == before)
            pairs_[idx].first = after;
          else
            pairs_[idx].second = after;

          hash_ ^= table_[index_for(idx)];
        }
      }

      quickUndo_ = true;
      return hash_;
    }

    hash_t undo_operation(const Grid &grid, uint32_t x, uint32_t y,
                          uint32_t n) noexcept {
      for (std::size_t j = 0; j < n; ++j) {
        for (std::size_t i = 0; i < n; ++i) {
          std::size_t idx = static_cast<std::size_t>(getter_(x + i, y + j, grid));
          hash_ ^= table_[index_for(idx)];

          uint32_t before = (y + j) * n_ + x + i,
              after = (y + n - 1 - i) * n_ + x + j;
          if (pairs_[idx].first == before)
            pairs_[idx].first = after;
          else
            pairs_[idx].second = after;

          hash_ ^= table_[index_for(idx)];
        }
      }

      quickUndo_ = false;
      return hash_;
    }

    hash_t undo_operation_quick() noexcept {
      if (!quickUndo_) {
        throw std::logic_error("undo_operation_quick() can only undo operation "
          "caused by apply_operation_with_quickundo()");
      }
      hash_ = saved_hash_;
      for (std::size_t i = 0; i < saved_indexes_.size(); ++i) {
        pairs_[saved_indexes_[i]] = saved_pairs_[saved_indexes_[i]];
      }

      quickUndo_ = false;
      return hash_;
    }

    [[nodiscard]] hash_t value() const noexcept { return hash_; }

  private:
    std::uint32_t n_;
    std::uint32_t p_len_;
    std::uint32_t h_len_;
    Getter getter_;
    std::vector<hash_t> table_;
    hash_t hash_;

    // undo section
    bool quickUndo_;
    hash_t saved_hash_;
    std::vector<std::uint32_t> saved_indexes_;
    std::vector<std::pair<value_t, value_t> > saved_pairs_;

    void init_table(std::uint64_t seed) noexcept {
      table_.clear();
      table_.resize(h_len_);
      std::uint64_t s = seed;
      for (std::size_t i = 0; i < h_len_; ++i) {
        table_[i] = SplitMix64::next(s);
      }
    }

    /*
        memo: h_len - (p_len * 2 - i)(p_len * 2 - 1 - i)/2 + j - i
    */
    inline std::size_t index_for(std::size_t pairs_index) {
      auto [first, second] = pairs_[pairs_index];
      if (second < first) {
        value_t tmp = second;
        second = first;
        first = tmp;
      }

      return h_len_ - (p_len_ * 2 - first) * (p_len_ * 2 - 1 - first) / 2 +
             second - first - 1;
    }
  };
} // namespace grid_hash

#ifndef EDGE_BEAM_HPP
#define EDGE_BEAM_HPP

namespace edge_beam_library {
  using namespace std;

  // 連想配列
  // Keyにハッシュ関数を適用しない
  // open addressing with linear probing
  // unordered_mapよりも速い
  // nは格納する要素数よりも16倍ほど大きくする
  template<class Key, class T>
  struct HashMap {
  public:
    explicit HashMap(uint32_t n) {
      if (n % 2 == 0) {
        ++n;
      }
      n_ = n;
      valid_.resize(n_, false);
      data_.resize(n_);
    }

    // 戻り値
    // - 存在するならtrue、存在しないならfalse
    // - index
    pair<bool, int> get_index(Key key) const {
      Key i = key % n_;
      while (valid_[i]) {
        if (data_[i].first == key) {
          return {true, i};
        }
        if (++i == n_) {
          i = 0;
        }
      }
      return {false, i};
    }

    // 指定したindexにkeyとvalueを格納する
    void set(int i, Key key, T value) {
      valid_[i] = true;
      data_[i] = {key, value};
    }

    // 指定したindexのvalueを返す
    T get(int i) const {
      assert(valid_[i]);
      return data_[i].second;
    }

    void clear() { fill(valid_.begin(), valid_.end(), false); }

  private:
    uint32_t n_;
    vector<bool> valid_;
    vector<pair<Key, T> > data_;
  };

  template<typename HashType>
  concept HashConcept = requires(HashType hash)
  {
    { std::is_unsigned_v<HashType> };
  };
  template<typename CostType>
  concept CostConcept = requires(CostType cost)
  {
    { std::is_arithmetic_v<CostType> };
  };

  template<typename StateType, typename HashType, typename CostType,
    typename ActionType, typename SelectorType>
  concept StateConcept =
      HashConcept<HashType> && CostConcept<CostType> &&
      requires(StateType state, SelectorType selector, CostType cost)
      {
        { state.expand(std::declval<int>(), selector, cost) } -> same_as<void>;
        { state.move_forward(std::declval<ActionType>()) } -> same_as<void>;
        { state.move_backward(std::declval<ActionType>()) } -> same_as<void>;
        { state.make_initial_node() } -> same_as<pair<CostType, HashType> >;
      };

  template<HashConcept Hash, typename Action, CostConcept Cost,
    template <typename> class State>
  struct EdgeBeamSearch {
    // ビームサーチの設定
    struct Config {
      int max_turn;
      size_t beam_width;
      size_t tour_capacity;
      uint32_t hash_map_capacity;
    };

    // 展開するノードの候補を表す構造体
    struct Candidate {
      Action action;
      Cost cost;
      Hash hash;
      int parent;

      Candidate(Action action, Cost cost, Hash hash, int parent)
        : action(action), cost(cost), hash(hash), parent(parent) {
      }
    };

    // ノードの候補から実際に追加するものを選ぶクラス
    // ビーム幅の個数だけ、評価がよいものを選ぶ
    // ハッシュ値が一致したものについては、評価がよいほうのみを残す
    class Selector {
    public:
      explicit Selector(const Config &config)
        : hash_to_index_(config.hash_map_capacity) {
        beam_width = config.beam_width;
        candidates_.reserve(beam_width);
        full_ = false;

        costs_.resize(beam_width);
        for (size_t i = 0; i < beam_width; ++i) {
          costs_[i] = {0, i};
        }
      }

      // 候補を追加する
      // ターン数最小化型の問題で、candidateによって実行可能解が得られる場合にのみ
      // finished = true とする ビーム幅分の候補をCandidateを追加したときにsegment
      // treeを構築する
      void push(const Action &action, const Cost &cost, const Hash &hash,
                int parent, bool finished) {
        Candidate candidate(action, cost, hash, parent);
        if (finished) {
          finished_candidates_.emplace_back(candidate);
          return;
        }
        if (full_ && cost >= st_.all_prod().first) {
          // 保持しているどの候補よりもコストが小さくないとき
          return;
        }
        auto [valid, i] = hash_to_index_.get_index(candidate.hash);

        if (valid) {
          int j = hash_to_index_.get(i);
          if (candidate.hash == candidates_[j].hash) {
            // ハッシュ値が等しいものが存在しているとき
            if (full_) {
              // segment treeが構築されている場合
              if (cost < st_.get(j).first) {
                candidates_[j] = candidate;
                st_.set(j, {cost, j});
              }
            } else {
              // segment treeが構築されていない場合
              if (cost < costs_[j].first) {
                candidates_[j] = candidate;
                costs_[j].first = cost;
              }
            }
            return;
          }
        }
        if (full_) {
          // segment treeが構築されている場合
          int j = st_.all_prod().second;
          hash_to_index_.set(i, candidate.hash, j);
          candidates_[j] = candidate;
          st_.set(j, {cost, j});
        } else {
          // segment treeが構築されていない場合
          int j = candidates_.size();
          hash_to_index_.set(i, candidate.hash, j);
          candidates_.emplace_back(candidate);
          costs_[j].first = cost;

          if (candidates_.size() == beam_width) {
            // 保持している候補がビーム幅分になったときにsegment treeを構築する
            full_ = true;
            st_ = MaxSegtree(costs_); // おかしい
          }
        }
      }

      // 選んだ候補を返す
      const vector<Candidate> &select() const { return candidates_; }

      // 実行可能解が見つかったか
      bool have_finished() const { return !finished_candidates_.empty(); }

      // 実行可能解に到達するCandidateを返す
      vector<Candidate> get_finished_candidates() const {
        return finished_candidates_;
      }

      // 最もよいCandidateを返す
      Candidate calculate_best_candidate() const {
        if (full_) {
          size_t best = 0;
          for (size_t i = 0; i < beam_width; ++i) {
            if (st_.get(i).first<st_.get(best).first) {
              best = i;
            }
          }
          return candidates_[best];
        } else {
          size_t best = 0;
          for (size_t i = 0; i < candidates_.size(); ++i) {
            if (costs_[i].first < costs_[best].first) {
              best = i;
            }
          }
          return candidates_[best];
        }
      }

      void clear() {
        candidates_.clear();
        hash_to_index_.clear();
        full_ = false;
      }

      void clear_finished_candidates() { finished_candidates_.clear(); }

    private:
      // 削除可能な優先度付きキュー
      using MaxSegtree =
      atcoder::segtree<pair<Cost, int>,
        [](pair<Cost, int> a, pair<Cost, int> b) {
          if (a.first >= b.first) {
            return a;
          } else {
            return b;
          }
        },
        []() {
          return make_pair(numeric_limits<Cost>::min(), -1);
        }>;

      size_t beam_width;
      vector<Candidate> candidates_;
      HashMap<Hash, int> hash_to_index_;
      bool full_;
      vector<pair<Cost, int> > costs_;
      MaxSegtree st_;
      vector<Candidate> finished_candidates_;
    };

    // Euler Tourを管理するためのクラス
    class Tree {
    public:
      vector<pair<int, Action> > curr_tour_;
      State<Selector> state_;

      struct LeafInfo {
        int leaf_index;
        State<Selector> state_snapshot;
      };

      vector<LeafInfo> leaves_info_;

      explicit Tree(const State<Selector> &state, const Config &config)
        : state_(state) {
        curr_tour_.reserve(config.tour_capacity);
        next_tour_.reserve(config.tour_capacity);
        leaves_.reserve(config.beam_width);
        buckets_.assign(config.beam_width, {});
      }

      // 状態を更新しながら深さ優先探索を行い、次のノードの候補を全てselectorに追加する
      void dfs(Selector &selector) {
        if (curr_tour_.empty()) {
          // 最初のターン
          auto [cost, hash] = state_.make_initial_node();
          state_.expand(0, selector);
          return;
        }

        for (auto [leaf_index, action]: curr_tour_) {
          if (leaf_index >= 0) {
            // 葉
            state_.move_forward(action);
            auto &[cost, hash] = leaves_[leaf_index];
            state_.expand(leaf_index, selector);
            state_.move_backward(action);
          } else if (leaf_index == -1) {
            // 前進辺
            state_.move_forward(action);
          } else {
            // 後退辺
            state_.move_backward(action);
          }
        }
      }

      // 木を更新する
      void update(const vector<Candidate> &candidates) {
        leaves_.clear();

        if (curr_tour_.empty()) {
          // 最初のターン
          for (const Candidate &candidate: candidates) {
            curr_tour_.push_back({(int) leaves_.size(), candidate.action});
            leaves_.push_back({candidate.cost, candidate.hash});
          }
          return;
        }

        for (const Candidate &candidate: candidates) {
          buckets_[candidate.parent].push_back(
            {candidate.action, candidate.cost, candidate.hash});
        }

        auto it = curr_tour_.begin();

        // 一本道を反復しないようにする
        while (it->first == -1 && it->second == curr_tour_.back().second) {
          Action action = (it++)->second;
          state_.move_forward(action);
          direct_road_.push_back(action);
          curr_tour_.pop_back();
        }

        // 葉の追加や不要な辺の削除をする
        while (it != curr_tour_.end()) {
          auto [leaf_index, action] = *(it++);
          if (leaf_index >= 0) {
            // 葉
            if (buckets_[leaf_index].empty()) {
              continue;
            }
            next_tour_.push_back({-1, action});
            for (auto [new_action, cost, hash]: buckets_[leaf_index]) {
              int new_leaf_index = leaves_.size();
              next_tour_.push_back({new_leaf_index, new_action});
              leaves_.push_back({cost, hash});
            }
            buckets_[leaf_index].clear();
            next_tour_.push_back({-2, action});
          } else if (leaf_index == -1) {
            // 前進辺
            next_tour_.push_back({-1, action});
          } else {
            // 後退辺
            auto [old_leaf_index, old_action] = next_tour_.back();
            if (old_leaf_index == -1) {
              next_tour_.pop_back();
            } else {
              next_tour_.push_back({-2, action});
            }
          }
        }
        swap(curr_tour_, next_tour_);
        next_tour_.clear();
      }

      // 根からのパスを取得する
      vector<Action> calculate_path(int parent, int turn) const {
        // cerr << curr_tour_.size() << endl;

        vector<Action> ret = direct_road_;
        ret.reserve(turn);
        for (auto [leaf_index, action]: curr_tour_) {
          if (leaf_index >= 0) {
            if (leaf_index == parent) {
              ret.push_back(action);
              return ret;
            }
          } else if (leaf_index == -1) {
            ret.push_back(action);
          } else {
            ret.pop_back();
          }
        }

        assert(false);
        return {};
      }

    private:
      vector<pair<int, Action> > next_tour_;
      vector<pair<Cost, Hash> > leaves_;
      vector<vector<tuple<Action, Cost, Hash> > > buckets_;
      vector<Action> direct_road_;
    };

    // dfsを元にした、葉ノードを収集する関数
    void collect_leaves(Tree &tree) {
      tree.leaves_info_.clear();

      if (tree.curr_tour_.empty()) {
        // 最初のターン
        tree.state_.make_initial_node();
        tree.leaves_info_.push_back({0, tree.state_});
        return;
      }

      for (auto [leaf_index, action]: tree.curr_tour_) {
        if (leaf_index >= 0) {
          // 葉
          tree.state_.move_forward(action);
          tree.leaves_info_.push_back({leaf_index, tree.state_});
          tree.state_.move_backward(action);
        } else if (leaf_index == -1) {
          // 前進辺
          tree.state_.move_forward(action);
        } else {
          // 後退辺
          tree.state_.move_backward(action);
        }
      }
    }

    void parallel_dfs(Tree &tree, BS::thread_pool<BS::tp::none> &pool,
                      vector<Selector> &selectors,
                      map<thread::id, unsigned int> &thread_id_map,
                      Cost best_cost) {
      collect_leaves(tree);

      if (tree.leaves_info_[0].leaf_index == 0 && tree.curr_tour_.empty()) {
        // 最初のターン
        tree.leaves_info_[0].state_snapshot.expand(0, selectors[0], best_cost);
        return;
      }

      // 各葉ノードのexpandをスレッドプールに投げる
      for (const auto &leaf_info: tree.leaves_info_) {
        pool.detach_task([&selectors, &leaf_info, &thread_id_map, best_cost]() {
          auto state_copy = leaf_info.state_snapshot;
          state_copy.expand(leaf_info.leaf_index,
                            selectors[thread_id_map[this_thread::get_id()]],
                            best_cost);
        });
      }

      // cout << " wait ...." << endl; 
      pool.wait();
    }

    // ビームサーチを行う関数
    vector<Action> beam_search(const Config &config,
                               const State<Selector> &state) {
      // 並列化用
      // constexpr unsigned int num_threads = 8;
      BS::thread_pool pool;
      map<thread::id, unsigned int> thread_id_map;
      vector<Selector> thread_local_selectors;
      auto v = pool.get_thread_ids();
      for (uint16_t i = 0; i < v.size(); ++i) {
        thread_id_map[v[i]] = i;
        thread_local_selectors.emplace_back(config);
      }

      Cost best_cost = numeric_limits<Cost>::max();

      Tree tree(state, config);

      // 新しいノード候補の集合
      Selector selector(config);

      for (int turn = 0; turn < config.max_turn; ++turn) {
        cout << '\r' << "turn" << turn + 1 << flush;
        // Euler Tourでselectorに候補を追加する
        // tree.dfs(selector);
        parallel_dfs(tree, pool, thread_local_selectors, thread_id_map,
                     best_cost);
        // cout << " xxx " << turn << endl;
        for (auto &local_selector: thread_local_selectors) {
          for (const auto &candidate: local_selector.select()) {
            selector.push(candidate.action, candidate.cost, candidate.hash,
                          candidate.parent, false);
          }
          for (const auto &candidate: local_selector.get_finished_candidates()) {
            selector.push(candidate.action, candidate.cost, candidate.hash,
                          candidate.parent, true);
          }
          local_selector.clear();
        }

        if (selector.have_finished()) {
          // ターン数最小化型の問題で実行可能解が見つかったとき
          Candidate candidate = selector.get_finished_candidates()[0];
          vector<Action> ret = tree.calculate_path(candidate.parent, turn + 1);
          ret.push_back(candidate.action);
          return ret;
        }
        assert(!selector.select().empty());

        if (turn == config.max_turn - 1) {
          // ターン数固定型の問題で全ターンが終了したとき
          Candidate best_candidate = selector.calculate_best_candidate();
          vector<Action> ret =
              tree.calculate_path(best_candidate.parent, turn + 1);
          ret.push_back(best_candidate.action);
          return ret;
        }

        best_cost = selector.calculate_best_candidate().cost;

        // 木を更新する
        tree.update(selector.select());

        selector.clear();
      }

      assert(false);
      return {};
    }

    // StateConcept のチェックを構造体内で実施
    static_assert(
      StateConcept<State<Selector>, Hash, Cost, Action, Selector>,
      "State template must satisfy StateConcept with BeamSearch::Selector");
  }; // EdgeBeamSearch

} // namespace edge_beam_library

using namespace edge_beam_library;
#endif

using namespace std;
using namespace nlohmann;

using Hash = uint64_t;

namespace ops {
  struct Ops {
    int x, y, n;
  };

  void to_json(json &j, const Ops &o) {
    j = json{{"x", o.x}, {"y", o.y}, {"n", o.n}};
  }
} // namespace ops

struct Input {
  int size;
  vector<vector<int> > entities;

  void input() {
    cin >> size;
    entities = vector<vector<int> >(size, vector<int>(size));
    for (int i = 0; i < size; ++i) {
      for (int j = 0; j < size; ++j) {
        cin >> entities[i][j];
      }
    }
  }

  void json_input(const json &j) {
    size = j["problem"]["field"]["size"].get<int>();
    entities = vector<vector<int> >(size, vector<int>(size));
    for (int i = 0; i < size; ++i) {
      entities[i] = j["problem"]["field"]["entities"][i].get<vector<int> >();
    }
  }
};

struct Action {
  uint16_t xyn;

  Action(uint16_t x, uint16_t y, uint16_t n) { xyn = (x << 10) | (y << 5) | n; }

  tuple<uint16_t, uint16_t, uint16_t> decode() const {
    return {xyn >> 10, (xyn >> 5) & 31, xyn & 31};
  }

  bool operator==(const Action &other) const { return xyn == other.xyn; }
};

using Cost = int;

using Grid = vector<uint8_t>;
uint32_t grid_size_gl = 4;

static uint32_t get_value(uint32_t x, uint32_t y, const Grid &grid) {
  return grid[y * grid_size_gl + x];
}

template<typename Selector>
class StateBase {
public:
  const uint16_t grid_size_;
  const uint16_t max_pair_;
  uint32_t pair_cnt_, turn_;
  Grid current_grid_, pair_history_;
  grid_hash::GridHash<Grid, decltype(&get_value)> hasher_;

  explicit StateBase(const Input &input)
    : grid_size_(input.size), max_pair_(grid_size_ * grid_size_ / 2),
      pair_cnt_(0), turn_(0), hasher_(grid_size_, get_value) {
    grid_size_gl = input.size;
    current_grid_.resize(grid_size_ * grid_size_);
    for (int i = 0; i < grid_size_; ++i) {
      for (int j = 0; j < grid_size_; ++j) {
        current_grid_[i * grid_size_ + j] = input.entities[i][j];
      }
    }
    pair_history_.reserve(max_turn);
    hasher_.build(current_grid_);
  }

  void expand(int parent, Selector &selector, Cost best_cost) {
    // 合法手の数だけループ
    int dist_sum = 0;
    int corner_bonus = 10; // 要調整
    int edge_bonus = 2; // 要調整
    for (uint8_t i = 0; i < grid_size_; ++i) {
      for (uint8_t j = 0; j < grid_size_; ++j) {
        if (hasher_.pairs_[current_grid_[i * grid_size_ + j]].first == i * grid_size_ + j) {
          dist_sum += abs(
            (int) (hasher_.pairs_[current_grid_[i * grid_size_ + j]].first % grid_size_) - (int) (
              hasher_.pairs_[current_grid_[i * grid_size_ + j]].second % grid_size_));
          dist_sum += abs(
            (int) (hasher_.pairs_[current_grid_[i * grid_size_ + j]].first / grid_size_) - (int) (
              hasher_.pairs_[current_grid_[i * grid_size_ + j]].second / grid_size_));
          if (abs((int) (hasher_.pairs_[current_grid_[i * grid_size_ + j]].first % grid_size_) - (int) (
                    hasher_.pairs_[current_grid_[i * grid_size_ + j]].second % grid_size_)) + abs(
                (int) (hasher_.pairs_[current_grid_[i * grid_size_ + j]].first / grid_size_) - (int) (
                  hasher_.pairs_[current_grid_[i * grid_size_ + j]].second / grid_size_)) == 1) {
            if (hasher_.pairs_[current_grid_[i * grid_size_ + j]].first == 0 || hasher_.pairs_[current_grid_[
                  i * grid_size_ + j]].first == grid_size_ - 1 || hasher_.pairs_[current_grid_[i * grid_size_ + j]].
                first == (grid_size_ - 1) * grid_size_ || hasher_.pairs_[current_grid_[i * grid_size_ + j]].first ==
                grid_size_ * grid_size_ - 1 || hasher_.pairs_[current_grid_[i * grid_size_ + j]].second == 0 || hasher_.
                pairs_[current_grid_[i * grid_size_ + j]].second == grid_size_ - 1 || hasher_.pairs_[current_grid_[
                  i * grid_size_ + j]].second == (grid_size_ - 1) * grid_size_ || hasher_.pairs_[current_grid_[
                  i * grid_size_ + j]].second == grid_size_ * grid_size_ - 1) {
              dist_sum -= corner_bonus;
            } else {
              if (hasher_.pairs_[current_grid_[i * grid_size_ + j]].first % grid_size_ == 0 || hasher_.pairs_[
                    current_grid_[i * grid_size_ + j]].first % grid_size_ == grid_size_ - 1 || hasher_.pairs_[
                    current_grid_[i * grid_size_ + j]].first / grid_size_ == 0 || hasher_.pairs_[current_grid_[
                    i * grid_size_ + j]].first / grid_size_ == grid_size_ - 1) {
                dist_sum -= edge_bonus;
              }
              if (hasher_.pairs_[current_grid_[i * grid_size_ + j]].second % grid_size_ == 0 || hasher_.pairs_[
                    current_grid_[i * grid_size_ + j]].second % grid_size_ == grid_size_ - 1 || hasher_.pairs_[
                    current_grid_[i * grid_size_ + j]].second / grid_size_ == 0 || hasher_.pairs_[current_grid_[
                    i * grid_size_ + j]].second / grid_size_ == grid_size_ - 1) {
                dist_sum -= edge_bonus;
              }
            }
          }
        }
      }
    }
    for (uint8_t n = 2; n < grid_size_; ++n) {
      for (uint8_t x = 0; x <= grid_size_ - n; ++x) {
        for (uint8_t y = 0; y <= grid_size_ - n; ++y) {
          Action new_action(x, y, n); // 新しいactionを作成

          move_forward(new_action); // 自由だが、ここでmove_forwardすると楽
          Hash new_hash = hasher_.value(); // move_forward内か、その後にthisから計算すると楽
          // int tmp = calc_dist(); 互換する
          int tmp = dist_sum;
          for (uint8_t i = 0; i < n; ++i) {
            for (uint8_t j = 0; j < n; ++j) {
              if (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first == (y + j) * grid_size_ + x + i) {
                if (!(x <= hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second % grid_size_ && hasher_.
                      pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second % grid_size_ < x + n && y <= hasher_.
                      pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second / grid_size_ && hasher_.pairs_[
                        current_grid_[(y + j) * grid_size_ + x + i]].second / grid_size_ < y + n)) {
                  tmp -= abs(
                    (int) (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first % grid_size_) - (int) (
                      hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second % grid_size_));
                  tmp -= abs(
                    (int) (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first / grid_size_) - (int) (
                      hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second / grid_size_));
                  if (abs((int) (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first % grid_size_) - (int)
                          (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second % grid_size_)) + abs(
                        (int) (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first / grid_size_) - (int) (
                          hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second / grid_size_)) == 1) {
                    if (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first == 0 || hasher_.pairs_[
                          current_grid_[(y + j) * grid_size_ + x + i]].first == grid_size_ - 1 || hasher_.pairs_[
                          current_grid_[(y + j) * grid_size_ + x + i]].first == (grid_size_ - 1) * grid_size_ || hasher_
                        .pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first == grid_size_ * grid_size_ - 1 ||
                        hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second == 0 || hasher_.pairs_[
                          current_grid_[(y + j) * grid_size_ + x + i]].second == grid_size_ - 1 || hasher_.pairs_[
                          current_grid_[(y + j) * grid_size_ + x + i]].second == (grid_size_ - 1) * grid_size_ ||
                        hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second == grid_size_ * grid_size_ -
                        1) {
                      dist_sum += corner_bonus;
                    } else {
                      if (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first % grid_size_ == 0 || hasher_
                          .pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first % grid_size_ == grid_size_ - 1 ||
                          hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first / grid_size_ == 0 || hasher_
                          .pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first / grid_size_ == grid_size_ - 1) {
                        dist_sum += edge_bonus;
                      }
                      if (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second % grid_size_ == 0 ||
                          hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second % grid_size_ == grid_size_
                          - 1 || hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second / grid_size_ == 0 ||
                          hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second / grid_size_ == grid_size_
                          - 1) {
                        dist_sum += edge_bonus;
                      }
                    }
                  }
                  tmp += abs(
                    (int) (x + n - 1 - j) - (int) (
                      hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second % grid_size_));
                  tmp += abs(
                    (int) (y + i) - (int) (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second /
                                           grid_size_));
                  if (abs((int) (x + n - 1 - j) - (int) (
                            hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second % grid_size_)) + abs(
                        (int) (y + i) - (int) (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second /
                                               grid_size_)) == 1) {
                    if ((y + i) * grid_size_ + (x + n - 1 - j) == 0 || (y + i) * grid_size_ + (x + n - 1 - j) ==
                        grid_size_ - 1 || (y + i) * grid_size_ + (x + n - 1 - j) == (grid_size_ - 1) * grid_size_ || (
                          y + i) * grid_size_ + (x + n - 1 - j) == grid_size_ * grid_size_ - 1 || hasher_.pairs_[
                          current_grid_[(y + j) * grid_size_ + x + i]].second == 0 || hasher_.pairs_[current_grid_[
                          (y + j) * grid_size_ + x + i]].second == grid_size_ - 1 || hasher_.pairs_[current_grid_[
                          (y + j) * grid_size_ + x + i]].second == (grid_size_ - 1) * grid_size_ || hasher_.pairs_[
                          current_grid_[(y + j) * grid_size_ + x + i]].second == grid_size_ * grid_size_ - 1) {
                      dist_sum -= corner_bonus;
                    } else {
                      if ((x + n - 1 - j) == 0 || (x + n - 1 - j) == grid_size_ - 1 || (y + i) == 0 || (y + i) ==
                          grid_size_ - 1) {
                        dist_sum -= edge_bonus;
                      }
                      if (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second % grid_size_ == 0 ||
                          hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second % grid_size_ == grid_size_
                          - 1 || hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second / grid_size_ == 0 ||
                          hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second / grid_size_ == grid_size_
                          - 1) {
                        dist_sum -= edge_bonus;
                      }
                    }
                  }
                }
              } else {
                if (!(x <= hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first % grid_size_ && hasher_.
                      pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first % grid_size_ < x + n && y <= hasher_.
                      pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first / grid_size_ && hasher_.pairs_[
                        current_grid_[(y + j) * grid_size_ + x + i]].first / grid_size_ < y + n)) {
                  tmp -= abs(
                    (int) (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first % grid_size_) - (int) (
                      hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second % grid_size_));
                  tmp -= abs(
                    (int) (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first / grid_size_) - (int) (
                      hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second / grid_size_));
                  if (abs((int) (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first % grid_size_) - (int)
                          (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second % grid_size_)) + abs(
                        (int) (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first / grid_size_) - (int) (
                          hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second / grid_size_)) == 1) {
                    if (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first == 0 || hasher_.pairs_[
                          current_grid_[(y + j) * grid_size_ + x + i]].first == grid_size_ - 1 || hasher_.pairs_[
                          current_grid_[(y + j) * grid_size_ + x + i]].first == (grid_size_ - 1) * grid_size_ || hasher_
                        .pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first == grid_size_ * grid_size_ - 1 ||
                        hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second == 0 || hasher_.pairs_[
                          current_grid_[(y + j) * grid_size_ + x + i]].second == grid_size_ - 1 || hasher_.pairs_[
                          current_grid_[(y + j) * grid_size_ + x + i]].second == (grid_size_ - 1) * grid_size_ ||
                        hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second == grid_size_ * grid_size_ -
                        1) {
                      dist_sum += corner_bonus;
                    } else {
                      if (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first % grid_size_ == 0 || hasher_
                          .pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first % grid_size_ == grid_size_ - 1 ||
                          hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first / grid_size_ == 0 || hasher_
                          .pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first / grid_size_ == grid_size_ - 1) {
                        dist_sum += edge_bonus;
                      }
                      if (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second % grid_size_ == 0 ||
                          hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second % grid_size_ == grid_size_
                          - 1 || hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second / grid_size_ == 0 ||
                          hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].second / grid_size_ == grid_size_
                          - 1) {
                        dist_sum += edge_bonus;
                      }
                    }
                  }
                  tmp += abs(
                    (int) (x + n - 1 - j) - (int) (
                      hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first % grid_size_));
                  tmp += abs(
                    (int) (y + i) - (int) (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first /
                                           grid_size_));
                  if (abs((int) (x + n - 1 - j) - (int) (
                            hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first % grid_size_)) + abs(
                        (int) (y + i) - (int) (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first /
                                               grid_size_)) == 1) {
                    if ((y + i) * grid_size_ + (x + n - 1 - j) == 0 || (y + i) * grid_size_ + (x + n - 1 - j) ==
                        grid_size_ - 1 || (y + i) * grid_size_ + (x + n - 1 - j) == (grid_size_ - 1) * grid_size_ || (
                          y + i) * grid_size_ + (x + n - 1 - j) == grid_size_ * grid_size_ - 1 || hasher_.pairs_[
                          current_grid_[(y + j) * grid_size_ + x + i]].first == 0 || hasher_.pairs_[current_grid_[
                          (y + j) * grid_size_ + x + i]].first == grid_size_ - 1 || hasher_.pairs_[current_grid_[
                          (y + j) * grid_size_ + x + i]].first == (grid_size_ - 1) * grid_size_ || hasher_.pairs_[
                          current_grid_[(y + j) * grid_size_ + x + i]].first == grid_size_ * grid_size_ - 1) {
                      dist_sum -= corner_bonus;
                    } else {
                      if ((x + n - 1 - j) == 0 || (x + n - 1 - j) == grid_size_ - 1 || (y + i) == 0 || (y + i) ==
                          grid_size_ - 1) {
                        dist_sum -= edge_bonus;
                      }
                      if (hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first % grid_size_ == 0 || hasher_
                          .pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first % grid_size_ == grid_size_ - 1 ||
                          hasher_.pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first / grid_size_ == 0 || hasher_
                          .pairs_[current_grid_[(y + j) * grid_size_ + x + i]].first / grid_size_ == grid_size_ - 1) {
                        dist_sum -= edge_bonus;
                      }
                    }
                  }
                }
              }
            }
          }
          Cost new_cost = (max_pair_ - pair_cnt_) * (200 - turn_) * 35 + tmp;
          bool finished = (max_pair_ == pair_cnt_); // ターン最小化問題で問題を解き終わったか
          move_backward(new_action); // 自由だが、ここでmove_forwardすると楽

          selector.push(new_action, new_cost, new_hash, parent, finished);
        }
      }
    }
  }

  // actionを実行して次の状態に遷移する
  void move_forward(const Action action) {
    ++turn_;
    pair_history_.emplace_back(pair_cnt_);
    auto [x, y, n] = action.decode();
    pair_diff(x, y, n);

    // rotate
    hasher_.apply_operation(current_grid_, x, y, n);
    for (uint8_t layer = 0; layer < n / 2; ++layer) {
      uint8_t first = layer;
      uint8_t last = n - 1 - layer;

      // 各辺の開始ポインタを計算
      uint8_t *ptr_top = &current_grid_[(y + first) * grid_size_ + x + first];
      uint8_t *ptr_left = &current_grid_[(y + last) * grid_size_ + x + first];
      uint8_t *ptr_bottom = &current_grid_[(y + last) * grid_size_ + x + last];
      uint8_t *ptr_right = &current_grid_[(y + first) * grid_size_ + x + last];

      for (uint8_t i = 0; i < (last - first); ++i) {
        uint16_t top_val = *(ptr_top + i);

        // top <- left
        *(ptr_top + i) = *(ptr_left - i * grid_size_);
        // left <- bottom
        *(ptr_left - i * grid_size_) = *(ptr_bottom - i);
        // bottom <- right
        *(ptr_bottom - i) = *(ptr_right + i * grid_size_);
        // right <- top
        *(ptr_right + i * grid_size_) = top_val;
      }
    }
  }

  // actionを実行する前の状態に遷移する
  /// @param action 実行したaction
  void move_backward(const Action action) {
    auto [x, y, n] = action.decode();
    hasher_.undo_operation(current_grid_, x, y, n);
    for (uint8_t layer = 0; layer < n / 2; ++layer) {
      uint8_t first = layer;
      uint8_t last = n - 1 - layer;

      // 各辺の開始ポインタを計算
      uint8_t *ptr_top = &current_grid_[(y + first) * grid_size_ + x + first];
      uint8_t *ptr_left = &current_grid_[(y + last) * grid_size_ + x + first];
      uint8_t *ptr_bottom = &current_grid_[(y + last) * grid_size_ + x + last];
      uint8_t *ptr_right = &current_grid_[(y + first) * grid_size_ + x + last];

      for (uint8_t i = 0; i < (last - first); ++i) {
        uint16_t top_val = *(ptr_top + i);

        // top <- right
        *(ptr_top + i) = *(ptr_right + i * grid_size_);
        // right <- bottom
        *(ptr_right + i * grid_size_) = *(ptr_bottom - i);
        // bottom <- left
        *(ptr_bottom - i) = *(ptr_left - i * grid_size_);
        // left <- top
        *(ptr_left - i * grid_size_) = top_val;
      }
    }
    pair_cnt_ = pair_history_.back();
    pair_history_.pop_back();
    --turn_;
  }

  void pair_diff(uint8_t x, uint8_t y, uint8_t n) {
    const bool top = (y != 0), bottom = (y + n != grid_size_), left = (x != 0),
        right = (x + n != grid_size_);

    if (top) {
      for (uint8_t i = 0; i < n; ++i) {
        if (current_grid_[y * grid_size_ + x + i] ==
            current_grid_[(y - 1) * grid_size_ + x + i]) {
          --pair_cnt_;
        }
        if (current_grid_[(y + i) * grid_size_ + x] ==
            current_grid_[(y - 1) * grid_size_ + x + n - 1 - i]) {
          ++pair_cnt_;
        }
      }
    }
    if (bottom) {
      for (uint8_t i = 0; i < n; ++i) {
        if (current_grid_[(y + n - 1) * grid_size_ + x + i] ==
            current_grid_[(y + n) * grid_size_ + x + i]) {
          --pair_cnt_;
        }
        if (current_grid_[(y + i) * grid_size_ + x + n - 1] ==
            current_grid_[(y + n) * grid_size_ + x + n - 1 - i]) {
          ++pair_cnt_;
        }
      }
    }
    if (left) {
      for (uint8_t i = 0; i < n; ++i) {
        if (current_grid_[(y + i) * grid_size_ + x] ==
            current_grid_[(y + i) * grid_size_ + x - 1]) {
          --pair_cnt_;
        }
        if (current_grid_[(y + n - 1) * grid_size_ + x + i] ==
            current_grid_[(y + i) * grid_size_ + x - 1]) {
          ++pair_cnt_;
        }
      }
    }
    if (right) {
      for (uint8_t i = 0; i < n; ++i) {
        if (current_grid_[(y + i) * grid_size_ + x + n - 1] ==
            current_grid_[(y + i) * grid_size_ + x + n]) {
          --pair_cnt_;
        }
        if (current_grid_[y * grid_size_ + x + i] ==
            current_grid_[(y + i) * grid_size_ + x + n]) {
          ++pair_cnt_;
        }
      }
    }
  }

  int calc_dist() {
    int sum = 0;
    vector<uint16_t> list(grid_size_ * grid_size_ / 2, 512);
    for (uint8_t i = 0; i < grid_size_; ++i) {
      for (uint8_t j = 0; j < grid_size_; ++j) {
        if (list[current_grid_[i * grid_size_ + j]] == 512)
          list[current_grid_[i * grid_size_ + j]] = i * grid_size_ + j;
        else {
          uint16_t tmp = list[current_grid_[i * grid_size_ + j]];
          uint32_t flagment = (i - tmp / grid_size_);
          uint16_t a = tmp % grid_size_, b = j;
          if (a < b)
            swap(a, b);

          uint16_t f = a - b;
          /*if((flagment == 2 && f == 1) || (flagment == 1 && f == 2) ||
             (flagment == 3 && f == 1) || (flagment == 1 && f == 3) || (flagment
             == 0 && (f == 2 || f == 3)) || ((flagment == 2 || flagment == 3) &&
             f == 0)) flagment += turn_ * turn_ * turn_ * turn_ / 1000000;*/
          /*if ((flagment == 2 && f == 1) || (flagment == 1 && f == 2)) {
              flagment += 24 * 24;
          }*/
          int lkj = 2;
          if (flagment + f == 1) {
            if (tmp == 0 || tmp == grid_size_ - 1 ||
                tmp == (grid_size_ - 1) * grid_size_ ||
                tmp == grid_size_ * grid_size_ - 1 || i * grid_size_ + j == 0 ||
                i * grid_size_ + j == grid_size_ - 1 ||
                i * grid_size_ + j == (grid_size_ - 1) * grid_size_ ||
                i * grid_size_ + j == grid_size_ * grid_size_ - 1) {
              sum -= 5 * lkj; // 要調整
            } else {
              if (tmp / grid_size_ == 0 || tmp % grid_size_ == 0 ||
                  tmp / grid_size_ == grid_size_ - 1 ||
                  tmp % grid_size_ == grid_size_ - 1) {
                sum -= 1 * lkj; // 要調整
              }
              if (i == 0 || j == 0 || i == grid_size_ - 1 ||
                  j == grid_size_ - 1) {
                sum -= 1 * lkj; // 要調整
              }
            }
          }
          flagment += (a - b);
          sum += flagment;
        }
      }
    }
    return sum;
  }

  // 初期状態のコストとハッシュを返す
  /// @return 初期状態のコストとハッシュ
  pair<Cost, Hash> make_initial_node() {
    int sum = 0;
    for (int i = 0; i < grid_size_ - 1; ++i) {
      for (int j = 0; j < grid_size_ - 1; ++j) {
        if (current_grid_[i * grid_size_ + j] ==
            current_grid_[(i + 1) * grid_size_ + j])
          ++sum;
        if (current_grid_[i * grid_size_ + j] ==
            current_grid_[i * grid_size_ + j + 1])
          ++sum;
      }
      if (current_grid_[(i + 1) * grid_size_ - 1] ==
          current_grid_[(i + 2) * grid_size_ - 1])
        ++sum;
      if (current_grid_[(grid_size_ - 1) * grid_size_ + i] ==
          current_grid_[(grid_size_ - 1) * grid_size_ + i + 1])
        ++sum;
    }
    pair_cnt_ = sum;
    return {(max_pair_ - sum) * 10 * turn_ + calc_dist(), hasher_.value()};
  }
};

using BeamSearchUser = EdgeBeamSearch<Hash, Action, Cost, StateBase>;
BeamSearchUser beam_search;
using State = StateBase<BeamSearchUser::Selector>;

string to_string(const ops::Ops &act) {
  return "x: " + to_string(act.x) + " y: " + to_string(act.y) + " n: " + to_string(act.n);
}

#ifdef LOCAL
#include "algo/debug.h"
#else
#define debug(...) 42
#endif

int main(int argc, char *argv[]) {
  ios::sync_with_stdio(false);
  cin.tie(nullptr);

  auto start_time = std::chrono::high_resolution_clock::now();

  debug("hello world");
  debug(max_turn);
  debug(BEAM_WIDTH);

  auto solv = solver::Solver(solver::Mode::Development, solver::IOType::File, solver::DataType::Json, argc, argv);

  if (solv.shouldExit()) {
    debug("should exit");
    return 0;
  }

  nlohmann::json inp = solv.getProblem();
  Input input;
  input.json_input(inp);
  debug(input.entities);

  constexpr int times = BEAM_WIDTH;
  BeamSearchUser::Config config = {
    .max_turn = max_turn,
    .beam_width = times,
    .tour_capacity = 100 * times,
    .hash_map_capacity = 64 * times, // 要素数の16倍ぐらいは必要らしい
  };
  State state(input);
  auto output = beam_search.beam_search(config, state);

  vector<ops::Ops> ops;
  for (auto &act: output) {
    auto [x, y, n] = act.decode();
    ops.emplace_back(ops::Ops({.x = (int) x, .y = (int) y, .n = (int) n}));
  }

  // debug(ops);

  json j;
  j["ops"] = ops;
  solv.submitAnswer(j);

  auto end_time = std::chrono::high_resolution_clock::now();
  auto duration = std::chrono::duration_cast<std::chrono::minutes>(end_time - start_time);
  debug("Time: ", duration.count(), " minutes");

  return 0;
}